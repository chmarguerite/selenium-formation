package fr.dawan.formation.stagiaire;


import java.util.List;
//import fr.dawan.formation.stagiaire.Note;

public class Stagiaire {

    private String nom;
   // private List<Note> notes;
    private int noteMoyenne;

    public Stagiaire(){}

    public Stagiaire(String nom){
        this.setNom(nom);
    }


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}
/*
	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
*/
	public int getNoteMoyenne() {
		return noteMoyenne;
	}

	public void setNoteMoyenne(int noteMoyenne) {
		this.noteMoyenne = noteMoyenne;
	}


}
