package fr.dawan.formation.stagiaire;


import java.util.*;

public class GestionStagiaire implements GestionStagiaireInterface {
    
    public GestionStagiaire() {}



    public Stagiaire consulterStagiaire(String nom) {
        return new Stagiaire(nom);
    }

   /* public void ajouterNote(String matricule, String cours, Integer note) {
        Note n = new Note(matricule, cours, note);
        
    }*/

    public Double calculerNoteMoyenne(String matricule) {
		return null;
    }

	public boolean consulterResultatExamen(Stagiaire stagiaire) {
			return (stagiaire.getNoteMoyenne() > 9);
	}

}





/****
 return notes.stream().mapToDouble(Note::getNote)
 .average().getAsDouble();****/