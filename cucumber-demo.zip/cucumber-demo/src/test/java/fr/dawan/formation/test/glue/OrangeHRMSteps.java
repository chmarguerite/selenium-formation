package fr.dawan.formation.test.glue;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Etantdonn�;
import cucumber.api.java.fr.Quand;

public class OrangeHRMSteps {
	WebDriver driver;
	@Before
	public void setupScenario() {
		System.setProperty("web.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@After
	public void afterScenario() {
	//	driver.quit();
	}
	
	
	@Etantdonn�("^je lance Orange HRM$")
	public void je_lance_Orange_HRM() throws Exception {
	   driver.get("http://orangehrm.selenium-formation.org/");
	}

	@Etantdonn�("^je me connecte avec les identifiants \"([^\"]*)\":\"([^\"]*)\"$")
	public void je_me_connecte_avec_les_identifiants(String login, String motDePasse) throws Exception {
		driver.findElement(By.id("txtUsername")).sendKeys(login);
		driver.findElement(By.id("txtPassword")).sendKeys(motDePasse);
		driver.findElement(By.id("btnLogin")).click();
	}

	@Etantdonn�("^je suis sur la page \"([^\"]*)\"$")
	public void je_suis_sur_la_page(String titre) throws Exception {
	    Assert.assertEquals(titre,driver.findElement(By.tagName("h1")).getText());
	}

	@Etantdonn�("^je navigue � la liste des employ�s$")
	public void je_navigue_�_la_liste_des_employ�s() throws Exception {
	    driver.findElement(By.linkText("GIP")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.linkText("Liste des employ�s")).click();
	    Thread.sleep(1000);
	}

	@Etantdonn�("^je clique sur le bouton Ajouter$")
	public void je_clique_sur_le_bouton_Ajouter() throws Exception {
		driver.findElement(By.id("btnAdd")).click();
	}

	@Quand("^je saisis \"([^\"]*)\" dans le champ Pr�nom$")
	public void je_saisis_dans_le_champ_Pr�nom(String prenom) throws Exception {
	    driver.findElement(By.id("firstName")).sendKeys(prenom);
	}

	@Quand("^je saisis \"([^\"]*)\" dans le champ Nom$")
	public void je_saisis_dans_le_champ_Nom(String nom) throws Exception {
	    driver.findElement(By.id("lastName")).sendKeys(nom);
	}

	@Quand("^je coche Cr�er d�tails de connexion$")
	public void je_coche_Cr�er_d�tails_de_connexion() throws Exception {
		driver.findElement(By.id("chkLogin")).click();
	}

	@Alors("^les champs suivants sont affich�s$")
	public void les_champs_suivants_sont_affich�s(List<List<String>> champs) throws Exception {
		champs.forEach((liste) -> {
			liste.forEach((texte) -> {
				assertTrue(driver.findElement(By.tagName("body")).getText().contains(texte));
			});
		});
	}

	@Alors("^le statut est Actif par d�faut$")
	public void le_statut_est_Actif_par_d�faut() throws Exception {
	    String statut= new Select(driver.findElement(By.id("status"))).getFirstSelectedOption().getText();
	    assertEquals("Actif",statut);
	}

	@Quand("^je saisis un nom d'utilisateur al�atoire$")
	public void je_saisis_un_nom_d_utilisateur_al�atoire() throws Exception {
		String nom="UUIYUIYIU";
	    driver.findElement(By.id("user_name")).sendKeys(nom);
	}
	String motDePasse;
	@Quand("^je saisis \"([^\"]*)\" dans le champ Mot de passe$")
	public void je_saisis_dans_le_champ_Mot_de_passe(String motDePasse) throws Exception {
			this.motDePasse=motDePasse;
		   driver.findElement(By.id("user_password")).sendKeys(motDePasse);
	}


	@Quand("^je confirme le mot de passe$")
	public void je_confirme_le_mot_de_passe() throws Exception {

		driver.findElement(By.id("re_password")).sendKeys(motDePasse);
	}

	@Quand("^je clique sur le bouton Sauvegarder$")
	public void je_clique_sur_le_bouton_Sauvegarder() throws Exception {
	    driver.findElement(By.id("btnSave")).click();
	}

	@Alors("^je suis sur la fiche de l'employ� \"([^\"]*)\"$")
	public void je_suis_sur_la_fiche_de_l_employ�(String nom) throws Exception {
	    assertTrue(driver.findElement(By.xpath("//h1[text()='" + nom +"']")).isDisplayed());
	}

}
