package fr.dawan.formation.test.glue;

import org.junit.Assert;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Etantdonn�;
import cucumber.api.java.fr.Quand;
import fr.dawan.formation.stagiaire.GestionStagiaire;
import fr.dawan.formation.stagiaire.Stagiaire;


public class NotesSteps {
	Stagiaire stagiaire;
	GestionStagiaire gestionStagiaire = new GestionStagiaire();
	
	@Etantdonn�("^j'ai un �l�ve nomm� \"([^\"]*)\"$")
	public void j_ai_un_�l�ve_nomm�(String nom) throws Exception {
	    stagiaire = new Stagiaire(nom);
	}

	@Quand("^cet �l�ve a obtenu une note de (\\d+)$")
	public void cet_�l�ve_a_obtenu_une_note_de(int note) throws Exception {
			stagiaire.setNoteMoyenne(note);
	}

	@Alors("^cet �l�ve a r�ussi l'examen$")
	public void cet_�l�ve_a_r�ussi_l_examen() throws Exception {
	    Assert.assertTrue(gestionStagiaire.consulterResultatExamen(stagiaire));
	}

	@Alors("^cet �l�ve a �chou� � l'examen$")
	public void cet_�l�ve_a_�chou�_�_l_examen() throws Exception {
		 Assert.assertFalse(gestionStagiaire.consulterResultatExamen(stagiaire));
	}

	@Quand("^cet �l�ve a obtenu les notes suivantes$")
	public void cet_�l�ve_a_obtenu_les_notes_suivantes(DataTable arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@Alors("^la note moyenne de cet �l�ve est (\\d+)$")
	public void la_note_moyenne_de_cet_�l�ve_est(int arg1) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
