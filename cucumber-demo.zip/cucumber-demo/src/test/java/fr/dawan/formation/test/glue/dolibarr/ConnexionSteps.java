package fr.dawan.formation.test.glue.dolibarr;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.fr.Etantdonn�;

public class ConnexionSteps {
	@FindBy(id="username")
	WebElement txtLogin;
	@FindBy(id="password")
	WebElement txtPassword;
	@FindBy(className="button")
	WebElement btnLogin;
	@FindBy(id="mainmenua_products")
	WebElement menuProduitServices;
	
	WebDriver driver;
	
	public  ConnexionSteps(TestContext testContext) {
		this.driver=testContext.driver;
		PageFactory.initElements(driver,this);
	}
	
	
	@Before
	public void setupScenario() {
		/*System.setProperty("web.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();*/
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@After
	public void afterScenario() {
		driver.quit();
	}
	
	
	
	@Etantdonn�("^je lance Dolibarr$")
	public void je_lance_Dolibarr() throws Exception {
	    driver.get("http://dolibarr.selenium-formation.org/");
	}

	@Etantdonn�("^je me connecte avec le profil suivant$")
	public void je_me_connecte_avec_le_profil_suivant(Map<String,String> identifiants) throws Exception {
		txtLogin.sendKeys(identifiants.get("Login"));
		txtPassword.sendKeys(identifiants.get("Password"));
		btnLogin.click();
	}

	@Etantdonn�("^je clique sur le menu \"([^\"]*)\"$")
	public void je_clique_sur_le_menu(String menu) throws Exception {
	    switch(menu) {
	    case "Produits | Services":
	    	menuProduitServices.click();
	    	break;
	    }
	}

}
