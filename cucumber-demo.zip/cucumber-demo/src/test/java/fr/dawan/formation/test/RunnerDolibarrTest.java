package fr.dawan.formation.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		tags="@Dolibarr",
		features="src/test/resources/features",
		glue="fr.dawan.formation.test.glue.dolibarr"
		)
public class RunnerDolibarrTest {

}
