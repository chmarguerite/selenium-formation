package fr.dawan.formation.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        tags = {"@Contact"},
        plugin = {"pretty","html:target/cucumber-report"},
        features = "src/test/resources/dolibarr/features",
        glue="fr.dawan.formation.cucumber.steps"
)
public class RunnerDolibarrFeatureTest {
}
