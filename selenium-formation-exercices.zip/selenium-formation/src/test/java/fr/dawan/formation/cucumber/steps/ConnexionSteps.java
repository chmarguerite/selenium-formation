package fr.dawan.formation.cucumber.steps;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Etantdonn�;
import cucumber.api.java.fr.Quand;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class ConnexionSteps {
    @FindBy(id="username")
    WebElement txtLogin;
    @FindBy(id="password")
    WebElement txtPassword;
    @FindBy(className="button")
    WebElement btnLogin;

    private ChromeDriver driver;
    public ConnexionSteps(TestContext context){
        this.driver=(ChromeDriver) context.driver;
        PageFactory.initElements(driver,this);
    }
    @Before
    public void setupDriver(){

    }
    @Etantdonn�("^je me connecte avec le profil suivant$")
    public void je_me_connecte_avec_le_profil_suivant(Map<String,String> identifiants) throws Exception {
        txtLogin.sendKeys(identifiants.get("Login"));
        txtPassword.sendKeys(identifiants.get("Password"));
        btnLogin.click();
    }
    @Etantdonn�("^je lance Dolibarr$")
    public void je_lance_Dolibarr() throws Exception {
        driver.get("http://dolibarr.selenium-formation.org");
    }

    @Quand("^je saisis \"([^\"]*)\" pour le champ Login$")
    public void je_saisis_pour_le_champ_Login(String username) throws Exception {
        txtLogin.sendKeys(username);
    }

    @Quand("^je saisis \"([^\"]*)\" pour le champ Password$")
    public void je_saisis_pour_le_champ_Password(String password) throws Exception {
        txtPassword.sendKeys(password);
    }

    @Quand("^je clique sur le bouton Login$")
    public void je_clique_sur_le_bouton_Login() throws Exception {
        btnLogin.click();
    }


    @Alors("^le titre de la page est \"([^\"]*)\"$")
    public void le_titre_de_la_page_est(String arg1) throws Exception {
        assertThat(driver.findElement(By.className("titre")).getText()).isEqualTo("Accueil");
    }

    @Alors("^il est affich� le lien \"([^\"]*)\"$")
    public void il_est_affich�_le_lien(String lien) throws Exception {
        assertThat(driver.findElement(By.linkText(lien)).isDisplayed()).isTrue();
    }

    @Alors("^l'utilisateur connect� est \"([^\"]*)\"$")
    public void l_utilisateur_connect�_est(String nom_utilisateur) throws Exception {
        assertThat(driver.findElement(By.className("usertext")).getText()).isEqualTo(nom_utilisateur);
    }





    @After
    public void closeDriver(){
        driver.close();
        driver.quit();
    }
}
