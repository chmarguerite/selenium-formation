package fr.dawan.formation.cucumber.panier;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Etantdonn�;
import cucumber.api.java.fr.Quand;
import fr.dawan.formation.Article;
import fr.dawan.formation.GestionPanier;
import fr.dawan.formation.Utilisateur;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;

public class PanierSteps {
    Utilisateur utilisateur;
    static GestionPanier gestionPanier=new GestionPanier();


    @Before
    public void setup(){

    }
    @Etantdonn�("^je suis l'utilisateur \"([^\"]*)\"$")
    public void je_suis_l_utilisateur(String user) throws Exception {
       utilisateur = new Utilisateur(user);
       gestionPanier.setUtilisateur(utilisateur);

    }
    List<Article> articles;
    @Etantdonn�("^les articles suivants sont r�f�renc�s$")
    public void les_articles_suivants_sont_r�f�renc�s(List<Article> articles) throws Exception {
        this.articles=articles;
        gestionPanier.setArticlesDB(articles);
    }

    @Etantdonn�("^mon panier est vide$")
    public void mon_panier_est_vide() throws Exception {
        Map<Article,Integer> vide= new HashMap<Article,Integer>();
        gestionPanier.setArticlesDuPanier(vide);
    }

    @Quand("^j'ajoute une quantit� de (\\d+) de l'article \"([^\"]*)\"$")
    public void j_ajoute_une_quantit�_de_de_l_article_r�f�renc�(int quantit�, String articleLabel) throws Exception {
        gestionPanier.ajouterArticle(articleLabel, quantit�);
    }

    @Alors("^le prix total de mon panier est (\\d+)$")
    public void le_prix_total_de_mon_panier_est(int prixTotal) throws Exception {
        assertThat(gestionPanier.calculerPrixTotal()).isEqualTo(prixTotal);
    }

    @Alors("^le nombre d'articles de mon panier est (\\d+)$")
    public void le_nombre_d_articles_de_mon_panier_est(int nombreArticles) throws Exception {
       assertThat(gestionPanier.obtenirNombreArticles()).isEqualTo(nombreArticles);
    }



    @Alors("^mon panier affiche les informations suivantes$")
    public void mon_panier_affiche_les_informations_suivantes(Map<String,String> infos) throws Exception {
        //assertThat(gestionPanier.obtenirNombreArticles()).isEqualTo(Integer.parseInt(infos.get("Nombre articles")));
        assertThat(gestionPanier.calculerPrixTotal()).isEqualTo(Double.parseDouble(infos.get("Prix total")));
    }

    @Alors("^mon panier reste vide$")
    public void mon_panier_reste_vide() throws Exception {
        assertThat(gestionPanier.estVide()).isTrue();
    }

    @Alors("^mon panier affiche le message \"([^\"]*)\"$")
    public void mon_panier_affiche_le_message(String message) throws Exception {
        assertThat(gestionPanier.afficherMessage()).isEqualTo(message);
    }

    
    @Etantdonn�("^je suis l�$")
    public void je_suis_l�(List<Map<String,String> >data) throws Exception {
    	System.out.println(data);
        System.out.print("Prix de " + data.get(0).get("article") + " est " + data.get(0).get("prix") );
    }

}
