package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import static org.assertj.core.api.Assertions.assertThat;
public class ExerciceGRH {

	private WebDriver driver;
	  private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();

	  @Before
	  public void setUp() throws Exception {
		 System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "https://www.katalon.com/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }

	  @Test
	  public void testUntitledTestCase() throws Exception {
	    driver.get("http://dolibarr.selenium-formation.org/");
	    driver.findElement(By.id("username")).sendKeys("jsmith");
	    driver.findElement(By.id("password")).sendKeys("Selenium&2018");
	    driver.findElement(By.cssSelector("input.button")).click();
	    driver.findElement(By.cssSelector("#mainmenua_hrm > span.mainmenuaspan")).click();
	    driver.findElement(By.xpath("(//a[contains(text(),'Nouveau')])[2]")).click();
	    driver.findElement(By.id("date_debut")).sendKeys("07/11/2019");
	    driver.findElement(By.id("date_fin")).sendKeys("07/11/2019");
	    new Select(driver.findElement(By.id("fk_user_validator"))).selectByVisibleText("John SMITH");
	    driver.findElement(By.name("bouton")).click();
	    driver.findElement(By.id("date")).sendKeys("07/11/2019");
	    new Select(driver.findElement(By.name("fk_c_type_fees"))).selectByVisibleText("Transport");
	    driver.findElement(By.name("value_unit")).sendKeys("150");
	    driver.findElement(By.name("bouton")).click();
	    driver.findElement(By.id("date")).sendKeys("07/11/2019");
	    new Select(driver.findElement(By.name("fk_c_type_fees"))).selectByVisibleText("Autre");
	    driver.findElement(By.name("value_unit")).sendKeys("30");
	    driver.findElement(By.name("bouton")).click();
	    assertThat(driver.findElement(By.xpath("//td[text()='Montant TTC']/following::td[1]")).getText()).isEqualTo("180,00 �");
	    driver.findElement(By.linkText("Valider et envoyer pour approbation")).click();
	  }

	  @After
	  public void tearDown() throws Exception {
	   // driver.quit();

	  }
}
