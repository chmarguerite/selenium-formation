package fr.dawan.formation.cucumber.steps;

import cucumber.api.PendingException;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Quand;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.lang.reflect.Field;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class TiersSteps {
    @FindBy(id = "name")
    WebElement txtNomDuTiers;
    @FindBy(id = "customerprospect")
    WebElement lstProspectClient;
    @FindBy(id = "fournisseur")
    WebElement lstFournisseur;
    @FindBy(id = "address")
    WebElement txtAdresse;
    @FindBy(id = "zipcode")
    WebElement txtCodePostal;
    @FindBy(id = "town")
    WebElement txtVille;
    @FindBy(name = "create")
    WebElement btnCr�erTiers;
    @FindBy(id = "status")
    WebElement lstEtat;
    @FindBy(id = "selectcountry_id")
    WebElement lstPays;

    private WebDriver driver;
    public TiersSteps(TestContext context){
        this.driver=(ChromeDriver) context.driver;
        PageFactory.initElements(driver,this);
    }

    @Quand("^je saisis \"([^\"]*)\" pour le champ Nom du tiers$")
    public void je_saisis_pour_le_champ_nom_du_tiers(String nom) throws Throwable {
        txtNomDuTiers.clear();
        txtNomDuTiers.sendKeys(nom);
    }

    @Quand("^je s�lectionne \"([^\"]*)\" pour la liste Prospect / Client$")
    public void je_s�lectionne_pour_la_liste_Prospect_Client(String prospectClient) throws Exception {
        new Select(lstProspectClient).selectByVisibleText(prospectClient);
    }

    @Quand("^je s�lectionne \"([^\"]*)\" pour la liste Fournisseur$")
    public void je_s�lectionne_pour_la_liste_Fournisseur(String fournisseur) throws Exception {
        new Select(lstFournisseur).selectByVisibleText(fournisseur);
    }


    @Alors("^la valeur de la liste Etat est \"([^\"]*)\"$")
    public void la_valeur_de_la_liste_Etat_est(String statut) throws Exception {
        assertThat(new Select(lstEtat).getFirstSelectedOption().getText()).isEqualTo("Ouvert");
    }

    @Alors("^la valeur de la liste Pays est \"([^\"]*)\"$")
    public void la_valeur_de_la_liste_Pays_est(String arg1) throws Exception {
        assertThat(new Select(lstPays).getFirstSelectedOption().getText()).isEqualTo("France (FR)");
    }

    @Quand("^je clique sur le bouton Cr�er tiers$")
    public void je_clique_sur_le_bouton_Cr�er_tiers() throws Exception {
        btnCr�erTiers.click();
        Thread.sleep(5000);
    }

    @Alors("^je suis sur la Fiche client$")
    public void je_suis_sur_la_Fiche_client() throws Exception {
        assertThat(driver.getTitle()).contains("Fiche");
    }

    @Alors("^les valeurs suivantes sont affich�es$")
    public void les_valeurs_suivantes_sont_affich�es(List<String> textes) throws Exception {
        textes.stream().forEach(texte -> {
            assertThat(driver.findElement(By.tagName("body")).getText()).contains(texte);
        });
    }
    String codeClient;
    @Alors("^je r�cup�re le code client$")
    public void je_r�cup�re_le_code_client() throws Exception {
        codeClient = driver.findElement(By.xpath("//td[text()='Code client']/following::td[1]")).getText();
    }
}
