package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import fr.dawan.formation.selenium.demo.objects.orangehrm.Connexion;

public class ExerciceG {
	ChromeDriver driver;
	
	@Before
	public void setup() {
        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://orangehrm.selenium-formation.org");
	}
	
	@Test
	public void creerPost() {
		Connexion connexionPage=PageFactory.initElements(driver, Connexion.class);
		connexionPage.nomUtilisateur.sendKeys("admin");
		connexionPage.motDePasse.sendKeys("Selenium&2018");
		connexionPage.connexion.click();
		
		
		
	}
	@After
	public void tearDown() {
		driver.close();
		driver.quit();
	}

}
