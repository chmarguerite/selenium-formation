package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ExerciceC {
	
	 
	 @Test
	    public void orange_valeurs_a_verifier() throws InterruptedException {
	
	        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("http://orangehrm.selenium-formation.org");
	        driver.findElement(By.id("txtUsername")).sendKeys("admin");
	        driver.findElement(By.id("txtPassword")).sendKeys("Selenium&2018");
	        driver.findElement(By.id("btnLogin")).click();
	        assertThat(driver.getTitle()).isEqualTo("OrangeHRM");
	        assertThat(driver.findElement(By.linkText("Admin")).isDisplayed()).isTrue();
	        assertThat(driver.findElement(By.tagName("body")).getText()).contains("Tableau de bord");
	        driver.findElement(By.linkText("Admin")).click();
	        assertThat(driver.findElement(By.tagName("body")).getText()).contains("Utilisateurs du syst�me");
	        assertThat(driver.findElement(By.id("btnAdd")).isDisplayed()).isTrue();
	        assertThat(driver.findElement(By.id("searchSystemUser_userName")).isDisplayed()).isTrue();
	        assertThat(driver.findElement(By.id("searchSystemUser_userName")).isEnabled()).isTrue();
	        driver.findElement(By.id("welcome")).click();
	        driver.findElement(By.linkText("D�connexion")).click();
	        try {
	        	driver.findElement(By.id("searchSystemUser_userName"));
			      assertThat(true).isFalse();
			    } catch (NoSuchElementException e) {
			    assertThat(true).isTrue();
			    }
	        driver.close();
	        driver.quit();
	    }
	 
	 @Test
	    public void orange_ajouter_salari�() throws InterruptedException {
	        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("http://orangehrm.selenium-formation.org");
	        driver.findElement(By.id("txtUsername")).sendKeys("admin");
	        driver.findElement(By.id("txtPassword")).sendKeys("Selenium&2018");
	        driver.findElement(By.id("btnLogin")).click();
	        driver.findElement(By.id("menu_pim_viewPimModule")).click();
	        driver.findElement(By.linkText("Liste des employ�s")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.id("btnAdd")).click();
	        driver.findElement(By.id("firstName")).sendKeys("Jos�");
	        driver.findElement(By.id("lastName")).sendKeys("SMITH");
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.id("personal_txtLicenNo")).sendKeys("XXXXXHHHHXXX");
	        driver.findElement(By.id("personal_optGender_1")).click();
	        new Select(driver.findElement(By.id("personal_cmbNation"))).selectByVisibleText("Fran�ais");
	        new Select(driver.findElement(By.id("personal_cmbMarital"))).selectByVisibleText("Mari�");
	        driver.findElement(By.id("personal_DOB")).sendKeys("2000-01-01");
	        String id=driver.findElement(By.id("personal_txtEmployeeId")).getAttribute("value");
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.linkText("Liste des employ�s")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.id("empsearch_id")).sendKeys(id);
	        driver.findElement(By.id("searchBtn")).click();
	        driver.findElement(By.linkText(id)).click();
	        assertThat(driver.findElement(By.id("personal_txtEmpFirstName")).getAttribute("value")).isEqualTo("Jos�");
	        driver.findElement(By.id("welcome")).click();
	        driver.findElement(By.linkText("D�connexion")).click();
	        driver.close();
	        driver.quit();

	    }

}
