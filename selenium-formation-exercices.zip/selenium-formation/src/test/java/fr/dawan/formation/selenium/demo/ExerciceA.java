package fr.dawan.formation.selenium.demo;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ExerciceA {

    @Test
    public void b_lancementChromeDriver() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.get("http://orangehrm.selenium-formation.org");
        Thread.sleep(5000);
        driver.close();
        driver.quit();

    }
    
    @Test
    public void a_lancementIEDriver() throws InterruptedException {
        System.setProperty("webdriver.ie.driver","drivers/IEDriverServer.exe");
        InternetExplorerDriver driver = new InternetExplorerDriver();
        driver.get("http://orangehrm.selenium-formation.org");
        Thread.sleep(5000);
        driver.close();
        driver.quit();

    }
}
