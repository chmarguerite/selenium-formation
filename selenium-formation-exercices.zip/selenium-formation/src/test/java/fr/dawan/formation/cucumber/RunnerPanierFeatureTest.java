package fr.dawan.formation.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty","html:target/cucumber-report"},
        features = "src/test/resources/formation/features",
        glue="fr.dawan.formation.cucumber.panier"
)
public class RunnerPanierFeatureTest {
}
