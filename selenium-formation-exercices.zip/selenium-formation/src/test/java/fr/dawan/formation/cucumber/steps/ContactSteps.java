package fr.dawan.formation.cucumber.steps;

import cucumber.api.PendingException;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Quand;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class ContactSteps {
    @FindBy(id = "lastname")
    WebElement txtNom;
    @FindBy(id = "address")
    WebElement txtAdresse;
    @FindBy(id = "zipcode")
    WebElement txtCodePostal;
    @FindBy(id = "town")
    WebElement txtVille;
    @FindBy(name = "add")
    WebElement btnAjouter;


    private WebDriver driver;
    public ContactSteps(TestContext context){
        this.driver=(ChromeDriver) context.driver;
        PageFactory.initElements(driver,this);
    }


    @Quand("^je renseigne les informations du contact$")
    public void je_renseigne_les_informations_du_contact(List<Map<String,String>> champs) throws Exception {
        champs.stream().forEach(ligne ->{
            ligne.entrySet().stream().forEach(champ ->{
                try {
                    Field field = this.getClass().getDeclaredField("txt" + champ.getKey().replace(" ",""));
                    WebElement element = (WebElement) field.get(this);
                    element.sendKeys(champ.getValue());
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }

            });

        });
    }

    @Alors("^le contact est Actif$")
    public void le_contact_est_Actif() throws Exception {
        assertThat(driver.findElement(By.xpath("//img[@title='Actif']")).isDisplayed()).isTrue();
        assertThat(driver.findElement(By.xpath("//span[contains(text(),'Actif')]")).isDisplayed()).isTrue();
    }

    @Quand("^je clique sur le bouton Ajouter$")
    public void je_clique_sur_le_bouton_Cr�er_tiers() throws Exception {
        btnAjouter.click();
        Thread.sleep(5000);
    }

}
