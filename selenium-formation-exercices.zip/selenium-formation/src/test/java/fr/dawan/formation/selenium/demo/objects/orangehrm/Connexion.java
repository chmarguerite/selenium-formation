package fr.dawan.formation.selenium.demo.objects.orangehrm;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Connexion {
	@FindBy(id="txtUsername")
	public WebElement nomUtilisateur;
	@FindBy(id="txtPassword")
	public WebElement motDePasse;
	@FindBy(id="btnLogin")
	public WebElement connexion;
	@FindBy(linkText="D�connexion")
	public WebElement d�connexion;
	
	WebDriver driver;
	
	public Connexion(WebDriver driver){
		this.driver=driver;
	}

}
