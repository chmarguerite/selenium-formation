package fr.dawan.formation.selenium.demo;


import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class CreationOrdinateur {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	    System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
    driver = new ChromeDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    driver.manage().window().maximize();
  }

  @Test
  public void testCreationOrdinateur() throws Exception {
    driver.get("http://demo.glpi-project.org/index.php");
    driver.findElement(By.id("login_name")).clear();
    driver.findElement(By.id("login_name")).sendKeys("admin");
    driver.findElement(By.id("login_password")).clear();
    driver.findElement(By.id("login_password")).sendKeys("admin");
    new Select(driver.findElement(By.name("language"))).selectByVisibleText("Fran�ais");
    driver.findElement(By.name("submit")).click();
    driver.findElement(By.linkText("Parc")).click();
    driver.findElement(By.linkText("Ordinateurs")).click();
    Thread.sleep(2000);
    driver.findElement(By.className("fa-plus")).click();
    driver.findElement(By.linkText("Gabarit vide")).click();
    driver.findElement(By.name("name")).clear();
    driver.findElement(By.name("name")).sendKeys("DAWAN");
    
    driver.findElement(By.xpath("//span[contains(@id,'dropdown_users_id_tech')]")).click();
    driver.findElement(By.xpath("//input[@type='search']")).clear();
    driver.findElement(By.xpath("//input[@type='search']")).sendKeys("glpi");
    driver.findElement(By.xpath("//span[contains(@title, 'glpi')]")).click();
    
    driver.findElement(By.name("contact_num")).clear();
    driver.findElement(By.name("contact_num")).sendKeys("000000111");
    driver.findElement(By.name("contact")).clear();
    driver.findElement(By.name("contact")).sendKeys("MARGUERITE");
    driver.findElement(By.xpath("//span[contains(@id,'dropdown_users_id')]")).click();
    driver.findElement(By.xpath("//input[@type='search']")).clear();
    driver.findElement(By.xpath("//input[@type='search']")).sendKeys("glpi");
    driver.findElement(By.xpath("//span[@title='glpi - glpi']")).click();
    driver.findElement(By.id("comment")).clear();
    driver.findElement(By.id("comment")).sendKeys("zezeze");
    driver.findElement(By.name("add")).click();
    driver.findElement(By.name("globalsearch")).clear();
    driver.findElement(By.name("globalsearch")).sendKeys("DAWAN");
    driver.findElement(By.xpath("//span[@id='champRecherche']/button/i")).click();
    driver.findElement(By.linkText("DAWAN")).click();
    driver.findElement(By.xpath("//a[contains(@href, '/front/logout.php')]")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}