package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import static org.assertj.core.api.Assertions.assertThat;

public class ExerciceShop {
	WebDriver driver;

    @Test
    public void test() {
        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
        int nombreAleatoire = 10000 + (int)(Math.random() * ((99999 - 10000) + 1));
        driver = new MyWebDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://demo.abantecart.com/");
        driver.findElement(By.linkText("Login or register")).click();
        driver.findElement(By.xpath("//button[@title='Continue']")).click();

        driver.findElement(By.name("firstname")).sendKeys("demo");
        driver.findElement(By.id("AccountFrm_lastname")).sendKeys("demo");
        driver.findElement(By.name("email")).sendKeys("demo" + nombreAleatoire + "@demo.org");
        driver.findElement(By.name("address_1")).sendKeys("2 rue libre");
        driver.findElement(By.name("postcode")).sendKeys("94000");
        driver.findElement(By.id("AccountFrm_city")).sendKeys("CRETEIL");
        new Select(driver.findElement(By.name("country_id"))).selectByVisibleText("France");
        new Select(driver.findElement(By.name("zone_id"))).selectByVisibleText("Picardie");
        driver.findElement(By.name("loginname")).sendKeys("demo" + nombreAleatoire);
        driver.findElement(By.name("password")).sendKeys("demotest");
        driver.findElement(By.name("confirm")).sendKeys("demotest");
        driver.findElement(By.name("agree")).click();
        driver.findElement(By.xpath("//button[@title='Continue']")).click();
        driver.findElement(By.linkText("Logoff")).click();

        driver.findElement(By.xpath("(//a[contains(text(),'Apparel & accessories')])[2]")).click();
        driver.findElement(By.xpath("(//a[contains(text(),'Shoes')])[2]")).click();
        driver.findElement(By.cssSelector("i.fa.fa-cart-plus.fa-fw")).click();
        driver.findElement(By.id("option342")).click();
        new Select(driver.findElement(By.id("option342"))).selectByVisibleText("40");
        driver.findElement(By.id("option342")).click();
        driver.findElement(By.linkText("Add to Cart")).click();
        assertThat(driver.findElement(By.xpath("//table[@id='totals_table']//tr[td[.='Total:']]/td[2]")).getText()).isEqualTo("$112.00");
      //  driver.close();
    }
}
