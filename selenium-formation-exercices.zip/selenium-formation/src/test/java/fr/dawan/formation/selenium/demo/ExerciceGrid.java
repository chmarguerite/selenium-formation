package fr.dawan.formation.selenium.demo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import fr.dawan.formation.selenium.demo.objects.orangehrm.Connexion;


public class ExerciceGrid {
	WebDriver driver;
	@Before
	public void setup(String navigateur) throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setBrowserName("internet explorer");
        driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), caps);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://orangehrm.selenium-formation.org");
	}
	
	@Test
	public void connexion() {
		Connexion connexionPage=PageFactory.initElements(driver, Connexion.class);
		connexionPage.nomUtilisateur.sendKeys("admin");
		connexionPage.motDePasse.sendKeys("Selenium&2018");
		connexionPage.connexion.click();
		
	}
	
	
	@After
	public void tearDown() {
		driver.close();
		driver.quit();
	}

}
