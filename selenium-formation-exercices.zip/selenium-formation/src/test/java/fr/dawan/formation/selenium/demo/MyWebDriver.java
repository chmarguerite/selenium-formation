package fr.dawan.formation.selenium.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyWebDriver extends ChromeDriver {
	 @Override
	    public WebElement findElement(By by) {
	        try {
	            Thread.sleep(5000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        return by.findElement((SearchContext) this);
	    }
}
