package fr.dawan.formation.selenium.demo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	ExerciceA.class,
	ExerciceC.class,
	ExerciceB.class
})
public class TestsSuite {

}
