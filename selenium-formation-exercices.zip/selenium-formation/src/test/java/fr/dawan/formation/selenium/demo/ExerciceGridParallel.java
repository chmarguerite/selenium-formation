package fr.dawan.formation.selenium.demo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import fr.dawan.formation.selenium.demo.objects.orangehrm.Connexion;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;

@RunWith(JUnitParamsRunner.class)
public class ExerciceGridParallel {
	WebDriver driver;
	

	  public static final String USERNAME = "claudehenrimargu1";
	  public static final String AUTOMATE_KEY = "z5YHnn7jWAb5BTjWRF7o";
	  public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";

	public WebDriver setupDriver(String navigateur) throws MalformedURLException {
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setBrowserName(navigateur);
        driver = new RemoteWebDriver(new URL(URL), caps); //"http://localhost:4444/wd/hub"
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
        return driver;
	}
	
	@Test
	@Parameters({
		"chrome",
		 "internet explorer"
	})
	public void connexion(String navigateur) throws MalformedURLException {
		driver = this.setupDriver(navigateur);
		driver.get("http://orangehrm.selenium-formation.org");

		Connexion connexionPage=PageFactory.initElements(driver, Connexion.class);
		connexionPage.nomUtilisateur.sendKeys("admin");
		connexionPage.motDePasse.sendKeys("Selenium&2018");
		
		connexionPage.connexion.click();
		
	}
	
	
	@After
	public void tearDown() {
		driver.close();
		driver.quit();
	}

}
