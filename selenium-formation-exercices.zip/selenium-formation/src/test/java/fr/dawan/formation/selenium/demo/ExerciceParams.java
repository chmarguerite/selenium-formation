package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import junitparams.Parameters;

@RunWith(JUnitParamsRunner.class)
public class ExerciceParams {
	@Test
	 @Parameters({
		 "toto,smith",
		 "titi,smith",
	 })
	    public void registerAccount(String pr�nom, String nom) throws InterruptedException {
	        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("http://newtours.demoaut.com");
	        driver.findElement(By.linkText("REGISTER")).click();
	        driver.findElement(By.name("firstName")).sendKeys(pr�nom);
	        driver.findElement(By.name("lastName")).sendKeys(nom);
	        driver.findElement(By.name("address1")).sendKeys("adresse");
	        driver.findElement(By.name("city")).sendKeys("CITY");
	        new Select(driver.findElement(By.name("country"))).selectByVisibleText("FRANCE");
	        driver.findElement(By.name("email")).sendKeys("test");
	        driver.findElement(By.name("password")).sendKeys("test");
	        driver.findElement(By.name("confirmPassword")).sendKeys("test");
	        driver.findElement(By.name("register")).click();
	        Thread.sleep(5000);
	        driver.findElement(By.linkText("SIGN-OFF")).click();
	        driver.close();
	        driver.quit();
	    }
	 
	 	@Test
	 	@FileParameters("src/test/resources/donn�es.csv")
	    public void registerAccount2(String pr�nom, String nom) throws InterruptedException {
	        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("http://newtours.demoaut.com");
	        driver.findElement(By.linkText("REGISTER")).click();
	        driver.findElement(By.name("firstName")).sendKeys(pr�nom);
	        driver.findElement(By.name("lastName")).sendKeys(nom);
	        driver.findElement(By.name("address1")).sendKeys("adresse");
	        driver.findElement(By.name("city")).sendKeys("CITY");
	        new Select(driver.findElement(By.name("country"))).selectByVisibleText("FRANCE");
	        driver.findElement(By.name("email")).sendKeys("test");
	        driver.findElement(By.name("password")).sendKeys("test");
	        driver.findElement(By.name("confirmPassword")).sendKeys("test");
	        driver.findElement(By.name("register")).click();
	        Thread.sleep(5000);
	        driver.findElement(By.linkText("SIGN-OFF")).click();
	        driver.close();
	        driver.quit();

	    }
/*	 
	 @Test
	    public void orange_ajouter_salari�() throws InterruptedException {
	        System.setProperty("webdriver.chrome.driver","drivers/chromedriver.exe");
	        ChromeDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	        driver.get("http://orangehrm.selenium-formation.org");
	        driver.findElement(By.id("txtUsername")).sendKeys("admin");
	        driver.findElement(By.id("txtPassword")).sendKeys("Selenium&2018");
	        driver.findElement(By.id("btnLogin")).click();
	        driver.findElement(By.id("menu_pim_viewPimModule")).click();
	        driver.findElement(By.linkText("Liste des employ�s")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.id("btnAdd")).click();
	        driver.findElement(By.id("firstName")).sendKeys("Jos�");
	        driver.findElement(By.id("lastName")).sendKeys("SMITH");
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.id("personal_txtLicenNo")).sendKeys("XXXXXHHHHXXX");
	        driver.findElement(By.id("personal_optGender_1")).click();
	        new Select(driver.findElement(By.id("personal_cmbNation"))).selectByVisibleText("Fran�ais");
	        new Select(driver.findElement(By.id("personal_cmbMarital"))).selectByVisibleText("Mari�");
	        driver.findElement(By.id("personal_DOB")).sendKeys("2000-01-01");
	        driver.findElement(By.id("btnSave")).click();
	        driver.findElement(By.id("welcome")).click();
	        driver.findElement(By.linkText("D�connexion")).click();
	        driver.close();
	        driver.quit();

	    }*/

}
