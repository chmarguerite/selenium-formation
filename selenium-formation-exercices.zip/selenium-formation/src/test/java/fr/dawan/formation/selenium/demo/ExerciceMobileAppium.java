package fr.dawan.formation.selenium.demo;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import fr.dawan.formation.selenium.demo.objects.orangehrm.Connexion;
import io.appium.java_client.remote.MobileCapabilityType;

public class ExerciceMobileAppium {
	WebDriver driver;
	@Before
	public void setup() throws MalformedURLException {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "HYF0219301000314");
		capabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
        driver = new RemoteWebDriver(new URL("http://localhost:4723/wd/hub"), capabilities);
        //driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://orangehrm.selenium-formation.org");
	}
	
	@Test
	public void connexion() throws InterruptedException {
		
		Connexion connexionPage=PageFactory.initElements(driver, Connexion.class);
		connexionPage.nomUtilisateur.sendKeys("admin");
		connexionPage.motDePasse.sendKeys("Selenium&2018");
		connexionPage.connexion.click();
		Thread.sleep(10000);
		
	}
	
	
	@After
	public void tearDown() {
		driver.close();
		driver.quit();
	}
}
