package fr.dawan.formation.selenium.demo;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExerciceD {
	
	 @Test
	    public void orange_ajouter_salari�() throws InterruptedException {
	     
	 	}

}
