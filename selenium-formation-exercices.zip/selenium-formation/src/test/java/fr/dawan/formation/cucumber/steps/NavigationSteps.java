package fr.dawan.formation.cucumber.steps;

import cucumber.api.PendingException;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Etantdonn�;
import cucumber.api.java.fr.Quand;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class NavigationSteps {
    @FindBy(className="fa-sign-out")
    WebElement btnD�connexion;

    private WebDriver driver;
    public NavigationSteps(TestContext context){
        this.driver=(ChromeDriver) context.driver;
        PageFactory.initElements(driver,this);
    }

    @Etantdonn�("^je clique sur le lien \"([^\"]*)\"$")
    public void je_clique_sur_le_lien(String lien) throws Exception {
        driver.findElement(By.linkText(lien)).click();
    }

    @Alors("^je clique sur D�connexion$")
    public void je_clique_sur_D�connexion() throws Exception {
       btnD�connexion.click();
    }

}
