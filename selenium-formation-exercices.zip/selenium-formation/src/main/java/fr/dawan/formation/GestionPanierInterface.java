package fr.dawan.formation;

public interface GestionPanierInterface {
    public void ajouterArticle(String r�f�rence, Integer quantit�);
    public Double calculerPrixTotal();
    public Integer obtenirNombreArticles();
    public boolean estVide();
    public String afficherMessage();
}
