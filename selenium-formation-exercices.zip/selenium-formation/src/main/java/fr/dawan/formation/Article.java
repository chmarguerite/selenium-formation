package fr.dawan.formation;

public class Article {
    private String r�f�rence;
    private String article;
    private Double prixUnitaire;
    private Integer stock;

    public Article(String r�f�rence, String article, Double prixUnitaire) {
        this.r�f�rence = r�f�rence;
        this.article = article;
        this.prixUnitaire = prixUnitaire;
    }

    public Double getPrixUnitaire() { return prixUnitaire;}
    public String getR�f�rence() { return r�f�rence; }
    public String getArticle() { return article; }
    public Integer getStock() { return stock; }
}
