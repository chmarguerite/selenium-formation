package fr.dawan.formation.stagiaire;


import java.util.List;

public interface GestionStagiaireInterface {

   // public List<Stagiaire> listeStagiaires();
    public Stagiaire consulterStagiaire(String matricule);
    //public void ajouterNote(String matricule, String cours,Integer note);
    public Double calculerNoteMoyenne(String matricule);
   // public boolean consulterResultatExamen(String matricule);


}
