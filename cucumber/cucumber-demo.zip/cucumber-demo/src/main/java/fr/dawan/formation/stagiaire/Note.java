package fr.dawan.formation.stagiaire;


public class Note {


    private String matricule;
    private String cours;
    private Integer note;

    public Note(){}

    public Note(String matricule, String cours, Integer note){
        this.setMatricule(matricule);
        this.setCours(cours);
        this.setNote(note);
    }

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getCours() {
		return cours;
	}

	public void setCours(String cours) {
		this.cours = cours;
	}

	public Integer getNote() {
		return note;
	}

	public void setNote(Integer note) {
		this.note = note;
	}

}
