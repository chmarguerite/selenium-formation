package fr.dawan.formation.stagiaire;


import java.util.List;

public class Stagiaire {

    private String nom;
    private List<Note> notes;

    public Stagiaire(){}

    public Stagiaire(String nom){
        this.setNom(nom);
    }


	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}


}
