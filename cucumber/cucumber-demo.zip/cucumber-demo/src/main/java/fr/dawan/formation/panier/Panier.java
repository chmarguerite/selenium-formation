package fr.dawan.formation.panier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Panier {
    private Utilisateur utilisateur;
    private Map<Article,Integer> articlesDuPanier = new HashMap<Article,Integer>();
    private Double prixTotal;
    private Integer nombreArticles;
    private String message;
    public Panier(){}
    public Panier(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }
    public Panier(Utilisateur utilisateur, Map<Article, Integer> articlesDuPanier) {
        this.utilisateur = utilisateur;
        this.articlesDuPanier = articlesDuPanier;
    }

    public Double getPrixTotal() { return prixTotal; }
    public void setPrixTotal(Double prixTotal) { this.prixTotal = prixTotal; }
    public Integer getNombreArticles() { return nombreArticles; }
    public void setNombreArticles(Integer nombreArticles) { this.nombreArticles = nombreArticles; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

}
