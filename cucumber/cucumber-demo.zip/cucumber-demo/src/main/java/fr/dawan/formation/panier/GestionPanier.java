package fr.dawan.formation.panier;

import java.util.*;
import java.util.concurrent.atomic.DoubleAdder;
import java.util.concurrent.atomic.LongAdder;

public class GestionPanier implements GestionPanierInterface {
    private Panier panier;
    private Utilisateur utilisateur;
    private Map<Article,Integer> articlesDuPanier = new HashMap<Article,Integer>();
    private List<Article> articlesDB=new ArrayList<Article>();

    public GestionPanier(){
        panier = new Panier();
    }

    public Panier getPanier(){
        return this.panier;
    }


    @Override
    public void ajouterArticle(String nom, Integer quantit�) {
        Optional<Article> article = articlesDB.stream().filter(map -> map.getArticle().equals(nom)).findFirst();

        if(article.isPresent()){
            if(article.get().getStock() > 0) {
                articlesDuPanier.put(article.get(), quantit�);
            }else{
                panier.setMessage("Article en rupture de stock");
            };
        }
    }

    @Override
    public Double calculerPrixTotal() {
        DoubleAdder somme = new DoubleAdder();
        articlesDuPanier.forEach((article,quantit�)->{
            somme.add(article.getPrixUnitaire()*quantit�);
        });
        panier.setPrixTotal(somme.doubleValue());
        return somme.doubleValue();
    }

    @Override
    public Integer obtenirNombreArticles() {
        return articlesDuPanier.values().stream().mapToInt(Integer::intValue).sum();
    }

    @Override
    public boolean estVide() {
        System.out.println(articlesDuPanier);
        return articlesDuPanier.isEmpty();
    }

    @Override
    public String afficherMessage() {
        return panier.getMessage();
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public void setArticlesDB(List<Article> articlesDB) {
        this.articlesDB = articlesDB;
    }
    public void setArticlesDuPanier(Map<Article,Integer> articlesDuPanier) {this.articlesDuPanier=articlesDuPanier; }
}
