package fr.bpifrance.dqops.qua.configuration;

import org.junit.platform.launcher.TestExecutionListener;

public class TestResultListener implements TestExecutionListener {
}
