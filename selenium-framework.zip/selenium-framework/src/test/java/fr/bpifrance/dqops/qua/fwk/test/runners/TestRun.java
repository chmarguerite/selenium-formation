package fr.bpifrance.dqops.qua.fwk.test.runners;

import com.mashape.unirest.http.exceptions.UnirestException;
import fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;

public class TestRun  extends AbstractSeleniumTest {
    WebDriver driver;
    @Test
    public void test() throws InterruptedException, UnirestException {
/*

        driver.get("https://jira.bpi.scs.on-x.eu/rest/api/2/group/member/?groupname=jira-software-users&maxResults=800");

        Thread.sleep(10000);
        driver.close();*/
    }

    private CharSequence getNumpad(String charAt) {
        switch (charAt){
            case "0": return Keys.NUMPAD0;
            case "1": return Keys.NUMPAD1;
            case "2": return Keys.NUMPAD2;
            case "3": return Keys.NUMPAD3;
            case "4": return Keys.NUMPAD4;
            case "5": return Keys.NUMPAD5;
            case "6": return Keys.NUMPAD6;
            case "7": return Keys.NUMPAD7;
            case "8": return Keys.NUMPAD8;
            case "9": return Keys.NUMPAD9;
            default: return "";
        }
    }
}
