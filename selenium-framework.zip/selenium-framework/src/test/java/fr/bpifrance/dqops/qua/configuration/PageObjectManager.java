package fr.bpifrance.dqops.qua.configuration;

import fr.bpifrance.dqops.qua.fwk.test.definitions.ExtendedWebElement;
import gherkin.deps.com.google.gson.JsonObject;
import gherkin.deps.com.google.gson.JsonParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PageObjectManager {
    private WebDriver driver;
    private String page;
    public ObjectsFileReader objectsFile;
    public ObjectsFileReader submitsFile;
    public ObjectsFileReader navigationsFile;
    public ObjectsFileReader linksFile;;

    public String getPage(){return page;}
    public void setPage(String page){
        this.page=page.toLowerCase().replace(" ", "_");
        objectsFile = new ObjectsFileReader(this.page);
        submitsFile= new ObjectsFileReader("0_actions");
        navigationsFile= new ObjectsFileReader("0_navigations");
        linksFile= new ObjectsFileReader("0_links");
    }

    public PageObjectManager( WebDriver driver){
        this.driver = driver;
      }

    public SeleniumElement get(String element){
        String element2=objectsFile.getElement(element.replace(" ","_"));
        if(element2.isEmpty()) {
            element2=new ObjectsFileReader("0_main").getElement(element.replace(" ","_"));
        }
        JsonParser parser = new JsonParser();
        try {
            JsonObject jsonElement = parser.parse(element2).getAsJsonObject();

            SeleniumElement bpiElement;
            if(jsonElement.get("extended") == null) {
                 bpiElement = new StandardWebElement(driver.findElement(By.xpath(jsonElement.get("locator").getAsString())));
            }else{
                StandardWebElement s = new StandardWebElement(driver.findElement(By.xpath(jsonElement.get("locator").getAsString())));
                 bpiElement = new ExtendedWebElement(driver,s);
            }
            if(jsonElement.get("destination") != null){
                bpiElement.setDestinationPage(jsonElement.get("destination").getAsString());
            }
            if(jsonElement.get("type") != null){
                bpiElement.setType(jsonElement.get("type").getAsString());
            }
            if(jsonElement.get("afterEvent") != null){
                bpiElement.setAfterEvent(jsonElement.get("afterEvent").getAsString());
            }
            if(jsonElement.get("method") != null){
                bpiElement.setMethod(jsonElement.get("method").getAsString());
            }
            bpiElement.setName(element);

            return bpiElement;
        }catch(Exception e){
            System.out.println("L'élément " + element +" n'est pas trouvé");
            throw e;
        }
    }


    public String getSubmit(String action) {
        String element2=submitsFile.getElement(action.replace(" ","_"));
        JsonParser parser = new JsonParser();
        if(!parser.parse(element2).isJsonNull()){
            JsonObject jsonElement=parser.parse(element2).getAsJsonObject();
            if(jsonElement.get("submit")!=null){
                return jsonElement.get("submit").getAsString();}
            else{
                return null;
            }
        }else{return null;}

    }

    public void navigateTo(String page){
        String navigation=navigationsFile.getElement(page.replace(" ","_"));
        String[] links=navigation.split(";");
        for(int i = 0;i<links.length;i++){
            if(links[i].contains("lien ")) {
                driver.findElement(By.linkText(links[i].replace("lien ",""))).click();
            }
        }

    }

    public String getLinkDestination(String lien) {
        String element2=linksFile.getElement(lien.replace(" ","_"));
        if(element2.isEmpty()){
            return null;
        }else {
            JsonParser parser = new JsonParser();
            if (!parser.parse(element2).isJsonNull()) {
                JsonObject jsonElement = parser.parse(element2).getAsJsonObject();
                if (jsonElement.get("destination") != null) {
                    return jsonElement.get("destination").getAsString();
                } else {
                    return null;
                }
            } else {
                return null;
            }
        }
    }
}
