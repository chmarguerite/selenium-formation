package fr.bpifrance.dqops.qua.configuration;

import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.support.ui.Select;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;

public class StandardWebElement implements SeleniumElement {

    TestContext testContext;
    private  WebElement element;
    private String destinationPage;
    private String XPath;
    private String type;
    private String name;
    private String afterEvent;
    private String method;
    public StandardWebElement(){}

    public StandardWebElement(WebElement element){
        this.element = element;
        this.afterEvent="";
        this.XPath = "";
        this.type="";
        this.name="";
        this.destinationPage="";
        this.method="";

    };

    public String getDestinationPage() {
        return destinationPage;
    }


    public void setDestinationPage(String destinationPage) {
        this.destinationPage = destinationPage;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void select(String valeur) {
        new Select(element).selectByVisibleText(valeur);
    }

    public void select2(String valeur) {

        String locator_arrow = "(//*[@id='" + element.getAttribute("id") + "']/following::span[@class='select2-selection__arrow'])[1]";
        String locator_search = "(//*[@id='" + element.getAttribute("id") + "']/following::input[@class='select2-search__field'])[1]";
        testContext.getContextDriver().findElement(By.xpath(locator_arrow)).click();
        testContext.getContextDriver().findElement(By.xpath(locator_search)).sendKeys(valeur);
        new Actions(testContext.getContextDriver()).sendKeys(Keys.ENTER).build().perform();

    }
    public String getValue() {
        return element.getAttribute("value");
    }

    public String getAfterEvent() {
        return this.afterEvent;
    }


    public void setAfterEvent(String afterEvent) {
        this.afterEvent=afterEvent;
    }

    public WebElement getElement() {
        return element;
    }


    public void dropbox(String valeur) {
        this.sendKeys(valeur);
        testContext.getContextDriver().findElement(By.xpath("//span[text()='" + valeur + "']/parent::div")).click();

    }

    public void matList(String valeur) {
        this.click();
        testContext.getContextDriver().findElement(By.xpath("//span[contains(text(),'" + valeur + "')]")).click();

    }


  /*  public void datePicker(String valeur) throws AWTException {
        //input[@aria-label='Date input field']/following::div[@class='placeholder']
        //String locator_placeholder= "(//*[@aria-label='" + element.getAttribute("aria-label") + "']/following::div[@class='placeholder'])[1]";
        //System.out.println(locator_placeholder);
        Actions builder  = new Actions(testContext.getContextDriver());
        builder.click(element);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_TAB);
        robot.keyRelease(KeyEvent.VK_TAB);
        robot.keyPress(KeyEvent.VK_TAB);
        robot.keyRelease(KeyEvent.VK_TAB);

        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }*/
  public String getMethod() {
      return this.method;
  }

    public void setMethod(String method) {
        this.method = method;
    }

    @Override
    public void click(){
        element.click();
    }

    private String getName() {
        return this.name;
    }

    @Override
    public void submit() {

    }

    @Override
    public void sendKeys(CharSequence... texte){
        element.sendKeys(texte);
    }

    @Override
    public void clear() {
        element.clear();
    }

    @Override
    public String getTagName() {
        return element.getTagName();
    }

    @Override
    public String getAttribute(String s) {
        return element.getAttribute(s);
    }

    @Override
    public boolean isSelected() {
        return element.isSelected();
    }

    @Override
    public boolean isEnabled() {
        return element.isEnabled();
    }

    @Override
    public String getText() {
        return element.getText();
    }

    @Override
    public List<WebElement> findElements(By by) {
        return element.findElements(by);
    }

    @Override
    public WebElement findElement(By by) {
        return element.findElement(by);
    }

    @Override
    public boolean isDisplayed() {
        return element.isDisplayed();
    }

    @Override
    public Point getLocation() {
        return element.getLocation();
    }

    @Override
    public Dimension getSize() {
        return element.getSize();
    }

    @Override
    public Rectangle getRect() {
        return element.getRect();
    }

    @Override
    public String getCssValue(String s) {
        return element.getCssValue(s);
    }


    @Override
    public <X> X getScreenshotAs(OutputType<X> outputType) throws WebDriverException {
        return element.getScreenshotAs(outputType);
    }


    public StandardWebElement setTestContext(TestContext testContext) {
        this.testContext  =testContext;
        return this;
    }

    public void setName(String element) {
        this.name = element;
    }


    @Override
    public Coordinates getCoordinates() {
        return null;
    }

    public String getXPath() {
        return XPath;
    }

    public void setXPath(String XPath) {
        this.XPath = XPath;
    }
}
