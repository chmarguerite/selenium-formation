package fr.bpifrance.dqops.qua.configuration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.internal.Locatable;
import org.openqa.selenium.internal.WrapsElement;

public interface SeleniumElement extends WebElement, Locatable {

    void setDestinationPage(String destination);
    void setType(String type);
    void setName(String element);
    String getDestinationPage();
    void select(String valeur);
    String getType();
    SeleniumElement setTestContext(TestContext testContext);
    Object getValue();
    String getAfterEvent();
    void setAfterEvent(String afterEvent);
    void setMethod(String method);
    WebElement getElement();
    String getMethod();
}
