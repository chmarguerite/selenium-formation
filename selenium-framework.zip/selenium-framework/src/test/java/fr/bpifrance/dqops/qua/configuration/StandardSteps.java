package fr.bpifrance.dqops.qua.configuration;


import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Et;
import cucumber.api.java.fr.Etantdonné;
import cucumber.api.java.fr.Quand;
import fr.bpifrance.dqops.qua.fwk.test.definitions.ExtendedSteps;
import fr.bpifrance.dqops.qua.fwk.test.definitions.ExtendedWebElement;
import io.cucumber.datatable.DataTable;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.YearMonth;
import java.util.*;
import java.util.List;

import static fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest.*;
import static org.assertj.core.api.Assertions.assertThat;

public class StandardSteps {

    PageObjectManager objectManager;
    TestContext testContext;
    ExtendedSteps extendedSteps;
    private WebDriver driver;
    private JavascriptExecutor js;
    WebTableElement tableau;
    Robot robot;
    public ConfigFileReader settings=new ConfigFileReader();

    public StandardSteps(){}
    public StandardSteps(TestContext testContext){
        this.testContext=testContext;
        objectManager = testContext.getPageObjectManager();
        driver = testContext.getContextDriver();
        this.js= (JavascriptExecutor)driver;
        try { robot = new Robot(); } catch (AWTException e) { e.printStackTrace(); }
        extendedSteps = new ExtendedSteps(testContext);

    }

    @Etantdonné("^je lance \"([^\"]*)\"$")
    public void je_lance_Application(String application) throws Throwable {
        if (isEmpty(SELENIUM_FRONT_URL)) {
            driver.get(settings.getApplicationUrl());}
        else{
            driver.get(SELENIUM_FRONT_URL);
        }

      /*  if(driver.getClass().toString().contains("Remote")) {
            js.executeScript("document.body.style.transform='scale(0.9)';");
        }*/
        je_suis_sur_la_page("Connexion " + application);
    }

    @Etantdonné("^je suis sur la page \"([^\"]*)\"$")
    public void je_suis_sur_la_page(String page) throws Throwable {
        Thread.sleep(2000);
        objectManager.setPage(page.toLowerCase());
        //Robot robot = new Robot();
        //robot.keyPress(KeyEvent.VK_PAGE_UP);
        //robot.keyRelease(KeyEvent.VK_PAGE_UP);
    }
/*
    @Alors("^je suis sur la page \"([^\"]*)\"$")
    public void alors_je_suis_sur_la_page(String page) throws Throwable {
        Thread.sleep(2000);
        objectManager.setPage(page.toLowerCase());
    }*/

    @Quand("^je saisis \"([^\"]*)\" dans le champ \"([^\"]*)\"$")
    public void je_saisis_dans_le_champ(String valeur, String champ) throws Throwable {
        objectManager.get(champ).click();
        objectManager.get(champ).clear();
        switch (objectManager.get(champ).getType()) {
            case "textfield":
            case "textarea":
                objectManager.get(champ).sendKeys(valeur);
                break;
            case "numeric":
                for(int i=0; i<valeur.length();i++){
                    objectManager.get(champ).sendKeys(getNumpad(valeur.substring(i,i+1)));
                }
                break;
            case "extended":
                System.out.println("c'est un extended " + objectManager.get(champ).getMethod());
                ExtendedWebElement e= new ExtendedWebElement(driver,objectManager.get(champ).getElement());
                ExtendedWebElement.class.getMethod(objectManager.get(champ).getMethod(),String.class).invoke(e, valeur);
                break;
        }
        String afterEvent=objectManager.get(champ).getAfterEvent();
        if (afterEvent !=null && afterEvent.equals("waitForJS")) {
            JSWaiter waiter = new JSWaiter();
            waiter.setDriver(driver);
            waiter.waitAllRequest(driver.getClass().toString());
        }
    }

    @Quand("^je sélectionne \"([^\"]*)\" pour la liste \"([^\"]*)\"$")
    public void je_selectionne_pour_la_liste(String valeur, String liste) throws Throwable {
        switch (objectManager.get(liste).getType()) {
            case "select":
                objectManager.get(liste).select(valeur);
                break;
            case "dropbox":
                StandardWebElement element1 = (StandardWebElement) objectManager.get(liste).setTestContext(testContext);
                element1.dropbox(valeur);
                break;
            case "mat-list":
                StandardWebElement element2 = (StandardWebElement) objectManager.get(liste).setTestContext(testContext);
                element2.matList(valeur);
                break;
            case "extended":
                System.out.println("c'est un extended " + objectManager.get(liste).getMethod());
                ExtendedWebElement e= new ExtendedWebElement(driver,objectManager.get(liste).getElement());
                ExtendedWebElement.class.getMethod(objectManager.get(liste).getMethod(),String.class).invoke(e, valeur);
                break;
        }

        String afterEvent=objectManager.get(liste).getAfterEvent();
        if (afterEvent !=null && afterEvent.equals("waitForJS")) {
            JSWaiter waiter = new JSWaiter();
            waiter.setDriver(driver);
            waiter.waitAllRequest(driver.getClass().toString());
        }
    }


    @Quand("^je choisis \"([^\"]*)\" concernant le sujet \"([^\"]*)\"")
    public void je_choisis_concernant_le_sujet(String valeur, String radio) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        switch (objectManager.get(radio).getType()) {
            case "radio":
                objectManager.get(radio +"_" + valeur).click();
                break;
            case "extended":
                System.out.println("c'est un extended " + objectManager.get(radio).getMethod());
                ExtendedWebElement e= new ExtendedWebElement(driver,objectManager.get(radio).getElement());
                ExtendedWebElement.class.getMethod(objectManager.get(radio).getMethod(),String.class).invoke(e, valeur);
                break;
        }
    }

    @Quand("^je clique sur le bouton \"([^\"]*)\"$")
    public void je_clique_sur_le_bouton(String bouton) throws Throwable {

        String destination=objectManager.get(bouton).getDestinationPage();
        String afterEvent=objectManager.get(bouton).getAfterEvent();
        if(!objectManager.get(bouton).getType().equals("file")){
            try{
                if(driver.getClass().toString().toLowerCase().contains("chrome") || System.getProperty("SELENIUM_BROWSER").toLowerCase().equals("chrome")) {

                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoViewIfNeeded(true);", objectManager.get(bouton).getElement());
                    try{
                        objectManager.get(bouton).click();
                    }catch(Exception e){
                        if(e.getMessage().contains("element not interactable")){
                            JavascriptExecutor javascript = (JavascriptExecutor) driver;
                            ((JavascriptExecutor) driver).executeScript("arguments[0].click();",    objectManager.get(bouton).getElement());
                        };
                        if(e.getMessage().contains("element click intercepted:") || e.getMessage().contains("element would receive") ){
                            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,2000)");
                            objectManager.get(bouton).click();
                            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-2000)");
                        };
                    }
                }else{
                    objectManager.get(bouton).click();
                   // ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);window.scrollBy(0,-100);", objectManager.get(bouton).getElement());
                }


            }
            catch(WebDriverException e){
                if(e.getMessage().contains("element click intercepted:") || e.getMessage().contains("element would receive") ){
                    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,2000)");
                    objectManager.get(bouton).click();
                    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0,-2000)");
                };

            }
        }else{
            // Des boutons file pour gérer la gestion des file IE
            new Actions(driver).moveToElement(objectManager.get(bouton).getElement()).build().perform();
            new Actions(driver).click().build().perform();
        }
        if (afterEvent !=null && afterEvent.equals("waitForJS")) {
            JSWaiter waiter = new JSWaiter();
            waiter.setDriver(driver);
            waiter.waitAllRequest(driver.getClass().toString());
        }
        if(destination !=null && !destination.isEmpty()){
            this.je_suis_sur_la_page(destination);
        }
    }

    @Quand("^je clique sur le lien \"([^\"]*)\"$")
    public void je_clique_sur_le_lien(String lien) throws Throwable {
        driver.findElement(By.linkText(lien)).click();
        if(objectManager.getLinkDestination(lien)==null){
        }else {
            String destination = objectManager.getLinkDestination(lien);
            if(destination != null){
                this.je_suis_sur_la_page(destination);
            }
        }
    }

    @Quand("^je clique sur le lien contenant \"([^\"]*)\"$")
    public void je_clique_sur_le_lien_contenant(String lien) throws Throwable {

        driver.findElement((By.partialLinkText(lien))).click();
        if(objectManager.getLinkDestination(lien)==null){
        }else {

            String destination = objectManager.getLinkDestination(lien);
            if(destination != null){
                this.je_suis_sur_la_page(destination);
            }

        }
    }



    @Alors("^il est affiché \"([^\"]*)\"$")
    public void il_est_affiché(String texte) throws Throwable {
        if(texte.startsWith("#") && texte.endsWith("#")){
            assertThat(driver.findElement(By.tagName("body")).getText()).containsPattern(texte.substring(1,texte.length()-1));
        }else{
            assertThat(driver.findElement(By.tagName("body")).getText()).contains(texte);
        }
    }

    @Alors("^il est affiché les textes$")
    public void il_est_affiché_les_textes(List<String> textes) throws Throwable {
        for(int i=0;i < textes.size();i++){
            String texte = textes.get(i);
            if(texte.startsWith("#") && texte.endsWith("#")){
                assertThat(driver.findElement(By.tagName("body")).getText()).containsPattern(texte.substring(1,texte.length()-1));
            }else{
                assertThat(driver.findElement(By.tagName("body")).getText()).contains(texte);
            }
        }
    }

    @Quand("^(.*) les informations suivantes$")
    public void je_complete_avec_les_informations_suivantes(String action, DataTable arg1) throws Throwable {
        try { //Je regarde si on n'a pas défini une méthode type pour cette

            action = action.replace(" ","_");
            extendedSteps.setAction(action).executeWith(arg1);
        }catch (NoSuchMethodException e) {

            Map<Object, Object> actions = arg1.asMaps(String.class, String.class).get(0);
            StandardWebElement element;
            for (Map.Entry<Object, Object> entry : actions.entrySet()) {
                if (!entry.getKey().toString().isEmpty()) {
                    //On se déplace à l'élément
                    element = (StandardWebElement) objectManager.get(entry.getKey().toString()).setTestContext(testContext);
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("arguments[0].scrollIntoView(false);", element.getElement());
                    switch (objectManager.get(entry.getKey().toString()).getType()) {
                        case "text":
                        case "textfield":
                        case "textarea":
                        case "numeric":
                            this.je_saisis_dans_le_champ(entry.getValue().toString(), entry.getKey().toString());
                            break;
                        case "select":
                            Thread.sleep(2000);
                            this.je_selectionne_pour_la_liste(entry.getValue().toString(), entry.getKey().toString());
                            break;
                        case "select2":
                            //element = (StandardWebElement) objectManager.get(entry.getKey()).setTestContext(testContext);
                            element.select2(entry.getValue().toString());
                            break;
                        case "ng-dropbox":
                            //element = (StandardWebElement) objectManager.get(entry.getKey()).setTestContext(testContext);
                            element.dropbox(entry.getValue().toString());
                            break;
                        case "mat-list":
                            //element = (StandardWebElement) objectManager.get(entry.getKey()).setTestContext(testContext);
                            //element.clear();
                            element.matList(entry.getValue().toString());
                            break;
                        case "datePicker":
                            js.executeScript("arguments[0].focus();", element.getElement());
                            js.executeScript("arguments[0].click();", element.getElement());
                            element.click();
                            element.click();
                            try{
                                driver.findElement(By.className("caltable")).isDisplayed();
                            }catch (NoSuchElementException ex){
                                element.click();
                            }
                            chooseDate(entry.getValue().toString());
                            Thread.sleep(2000);
                            break;
                        case "radio":
                            objectManager.get(entry.getKey().toString() +"_" + entry.getValue().toString()).click();
                            break;
                        case "extended":
                            System.out.println("c'est un extended " + objectManager.get(entry.getKey().toString()).getMethod());
                            ExtendedWebElement extendedWebElement= new ExtendedWebElement(driver,objectManager.get(entry.getKey().toString()).getElement());
                            ExtendedWebElement.class.getMethod(objectManager.get(entry.getKey().toString()).getMethod(),String.class).invoke(extendedWebElement, entry.getValue().toString());
                            break;
                    }
                }
            }

            //Je poste
            if (objectManager.getSubmit(action) != null) {
                //Je fais une tabulation avant pour gérer le problème de focus sur la dernière action
               // Robot robot = new Robot();
               // robot.keyPress(KeyEvent.VK_TAB);
                // robot.keyRelease(KeyEvent.VK_TAB);
                Thread.sleep(500);
                //robot.keyPress(KeyEvent.VK_PAGE_DOWN);
              //  robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
                this.je_clique_sur_le_bouton(objectManager.getSubmit(action));
            }
        }
    }


    @Alors("^le tableau \"([^\"]*)\" est affiché$")
    public void le_tableau_est_affiché(String texte) throws Throwable {
        if(driver.findElements(By.xpath("//table[.//td='" + texte + "' or .//th='" + texte+ "']")).size() > 0) {
            tableau = new WebTableElement(driver.findElement(By.xpath("//table[.//td='" + texte + "' or .//th='" + texte + "']")));
            assertThat(tableau).isNotNull();
        }else{
            tableau = new WebTableElement(objectManager.get(texte).getElement());
            assertThat(tableau).isNotNull();
        }
    }

    @Alors("^les valeurs des cellules suivantes sont affichées$")
    public void les_valeurs_des_cellules_suivantes_sont_affichées(DataTable arg1) throws Throwable {
        List<List<String>> attendus = arg1.asLists();
        List<List<String>> obtenus = tableau.getRawList();
        for(List<String> attendu:attendus){
            Iterator<List<String>> iterator = obtenus.iterator();
            Boolean trouve=false;
            while(iterator.hasNext()){
                List<String> ligne = iterator.next();
                if(ligne.containsAll(attendu)){
                    trouve=true;
                    break;
                }

            }
            assertThat(trouve).isTrue();
        }

        /*
        if(arg1.getGherkinRows().get(0).getCells().equals(Arrays.asList("Ligne","Valeur"))){
            List<Map<String,String>> lignes = arg1.asMaps(String.class,String.class);
            Iterator<Map<String,String>> i =lignes.iterator();

            while (i.hasNext()){
                Map<String,String> ligne = i.next();
                assertThat(tableau.getCellByText(ligne.get("Ligne")).isDisplayed()).isTrue();
                assertThat(tableau.getCellByTextInCurrentRow(ligne.get("Valeur")).isDisplayed()).isTrue();
            }
        }else {
            Map<String, String> actions = arg1.asMaps(String.class, String.class).get(0);
            for (Map.Entry<String, String> entry : actions.entrySet()) {
                if (!entry.getKey().isEmpty()) {
                    assertThat(tableau.getCellByText(entry.getKey()).isDisplayed()).isTrue();
                    assertThat(tableau.getCellByText(entry.getValue()).isDisplayed()).isTrue();

                }
            }
        }*/
    }

    @Et("^il est affiché l'élément \"([^\"]*)\"$")
    public void il_est_affiché_l_élément(String element) throws Throwable {
        assertThat(objectManager.get(element).isDisplayed()).isTrue();
    }

    @Et("^il est affiché les éléments$")
    public void il_est_affiché_les_éléments(List<String> elements) throws Throwable {

        for(int i=0;i < elements.size();i++){
            assertThat(objectManager.get(elements.get(i)).isDisplayed()).isTrue();
        }

    }

    @Et("^les valeurs par défauts suivantes sont affichées$")
    public void les_valeurs_par_défauts_suivantes_sont_affichées(DataTable arg1) throws Throwable {
        Map<Object,Object> actions =  arg1.asMaps(String.class,String.class).get(0);
        for (Map.Entry<Object, Object> entry : actions.entrySet()) {
            if(!entry.getKey().toString().isEmpty()) {
                switch (objectManager.get(entry.getKey().toString()).getType()) {
                    case "textfield":
                    case "textarea":
                        assertThat(objectManager.get(entry.getKey().toString()).getValue()).isEqualTo(entry.getValue());
                        break;
                    case "select":
                        assertThat(new Select(objectManager.get(entry.getKey().toString())).getFirstSelectedOption().getText().trim()).isEqualTo(entry.getValue());
                        objectManager.get(entry.getKey().toString()).select(entry.getValue().toString());
                        break;

                }
            }
        }
    }

    @Quand("^je navigue à la page \"([^\"]*)\"$")
    public void je_navigue_a_la_page(String page) throws Throwable {
        objectManager.navigateTo(page);
        this.je_suis_sur_la_page(page);
    }
    @Et("^j'uploade le fichier suivant \"([^\"]*)\"$")
    public void j_uploade_le_fichier_suivant(String fichier) throws Throwable {
        j_ajoute_le_fichier_suivant(fichier);
    }

    @Et("^j'ajoute le fichier suivant \"([^\"]*)\"$")
    public void j_ajoute_le_fichier_suivant(String fichier) throws Throwable {
      //  System.out.println("page" + objectManager.getPage());

        /*StringSelection selection = new StringSelection(fichier);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(selection, selection);
        Thread.sleep(2000);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        Thread.sleep(2000);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(2000);*/
    }

    @Quand("^je sélectionne la ligne (\\d+) de ce tableau$")
    public void je_sélectionne_la_ligne_de_ce_tableau(int ligne) {
        tableau.getRows().get(ligne).click();
    }


    @Et("^j'attends la fin du traitement$")
    public void j_attends_la_fin_du_traitement() throws InterruptedException {
        JSWaiter waiter= new JSWaiter();
        waiter.setDriver(driver);
        waiter.waitAllRequest(driver.getClass().toString());
    }
    @Et("^j'attends longtemps$")
    public void j_attends_longtemps() throws InterruptedException {
        Thread.sleep(60000);
    }
    // Vérifie la présence d'un élément avec le texte en paramètre
    @Alors("^il est affiché un élément texte \"([^\"]*)\"$")
    public void il_est_affiché_un_élément_texte(String arg0) throws Throwable {
        Thread.sleep(2000);
    	assertThat(driver.findElement(By.xpath("//*[contains(text(),'" + arg0 + "')]")).isDisplayed()).isTrue();

    }

    //Vérifié l'abscence d'éléments
    @Et("^il n'est pas affiché les éléments$")
    public void il_n_est_pas_affiché_les_éléments(List<String> elements) {
        for(int i=0;i < elements.size();i++){
            assertThat(objectManager.get(elements.get(i))).isNull();
        }
    }

    //Pour le champs Datepicker
    public void chooseDate(String date) {

        if (date.toLowerCase().equals("jour")) {
            int jour = LocalDateTime.now().getDayOfMonth();
            driver.findElement(By.xpath("//td[contains(@class,'daycell')][.//span[text()='"+ jour + "']]")).click();
        } else {
            String year = date.substring(4, 8);
            String month = date.substring(2, 4);
            String day = date.substring(0, 2);
            if (day.startsWith("0")) {
                day = day.substring(1);
            }
            ;
            Float clickYear = Float.parseFloat(Year.now().toString()) - Float.parseFloat(year);
            if (clickYear > 0) {
                for (int i = 1; i <= clickYear; i++) {
                    driver.findElement(By.xpath("//button[@aria-label='Previous Year']")).click();
                }
            }
            if (clickYear < 0) {
                for (int i = 1; i <= -clickYear; i++) {
                    driver.findElement(By.xpath("//button[@aria-label='Next Year']")).click();
                }
            }
            Float clickMonth = YearMonth.now().getMonth().getValue() - Float.parseFloat(month);
            if (clickMonth > 0) {
                for (int i = 1; i <= clickMonth; i++) {
                    driver.findElement(By.xpath("//button[@aria-label='Previous Month']")).click();
                }
            }
            if (clickMonth < 0) {
                for (int i = 1; i <= -clickMonth; i++) {
                    driver.findElement(By.xpath("//button[@aria-label='Next Month']")).click();
                }
            }

            driver.findElement(By.xpath("//td[contains(@class,'daycell')][.//span[text()='"+ day + "']]")).click();
        }
    }

    private CharSequence getNumpad(String charAt) {
        switch (charAt){
            case "0": return Keys.NUMPAD0;
            case "1": return Keys.NUMPAD1;
            case "2": return Keys.NUMPAD2;
            case "3": return Keys.NUMPAD3;
            case "4": return Keys.NUMPAD4;
            case "5": return Keys.NUMPAD5;
            case "6": return Keys.NUMPAD6;
            case "7": return Keys.NUMPAD7;
            case "8": return Keys.NUMPAD8;
            case "9": return Keys.NUMPAD9;
            default: return "0";
        }
    }

    @Et("^je clique sur \"([^\"]*)\"$")
    public void je_clique_sur(String element) throws Throwable {
        driver.findElement(By.xpath("//*[contains(text(),'" + element + "')]")).click();

    }
    @Et("^je clique sur l'élément \"([^\"]*)\"$")
    public void je_clique_sur_l(String element) throws Throwable {
        this.je_clique_sur_le_bouton(element);
    }

    @Et("le bouton \"([^\"]*)\" est désactivé")
    public void le_bouton_est_désactivé(String bouton) {
        assertThat(objectManager.get(bouton).isEnabled()).isFalse();
    }

    @Et("le bouton \"([^\"]*)\" est activé")
    public void le_bouton_est_activé(String bouton) {
        assertThat(objectManager.get(bouton).isEnabled()).isTrue();
    }
}
