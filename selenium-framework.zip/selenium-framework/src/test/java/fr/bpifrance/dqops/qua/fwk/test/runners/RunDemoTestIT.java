package fr.bpifrance.dqops.qua.fwk.test.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

@RunWith(Cucumber.class)
@CucumberOptions(
		tags = {"@Dolibarr"},
		plugin = {"pretty", "html:target/cucumber", "json:target/cucumber.json"},
		features="src/test/resources/features/",
		glue = {"fr.bpifrance.dqops.qua"})
public class RunDemoTestIT extends AbstractSeleniumTest {
	/*@AfterClass
	public static void generateExecutionReport() throws Exception {
		Process process = Runtime.getRuntime().exec("java -jar target/test-classes/cukedoctor.jar -p target/cucumber.json -o target/report -f pdf");
		StringBuilder output = new StringBuilder();
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(process.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {
			output.append(line + "\n");
		}
		int exitVal = process.waitFor();
		if (exitVal == 0) {
			System.out.println("Rapport de test généré!");
			System.out.println(output);
		}


	}*/
}
