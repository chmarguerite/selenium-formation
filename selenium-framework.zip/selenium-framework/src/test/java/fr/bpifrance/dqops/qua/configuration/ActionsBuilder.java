package fr.bpifrance.dqops.qua.configuration;

import io.cucumber.datatable.DataTable;

import java.lang.reflect.InvocationTargetException;

public class ActionsBuilder {
    private String action;
    private TestContext testContext;

    public ActionsBuilder(TestContext context){
        this.setTestContext(context);
    }

    public void executeWith(DataTable arg1) throws Exception {
        this.getClass().getMethod(this.action,DataTable.class).invoke(this, arg1);
    }

    public String getAction() { return action; }

    public ActionsBuilder setAction(String action) { this.action = action; return this; }

    public TestContext getTestContext() {
        return testContext;
    }

    public ActionsBuilder setTestContext(TestContext testContext) {
        this.testContext = testContext;
        return this;
    }
}
