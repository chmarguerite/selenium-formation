package fr.bpifrance.dqops.qua.configuration;

import org.assertj.core.api.SoftAssertions;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.service.DriverService;
import org.openqa.selenium.support.ui.Select;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

/**
 * Cette classe lié à l'énumeration Browser permet de découpler le paramétrage sélénium :
 * <ul>
 * 	<li>Si SELENIUM_HUB_URL est précisé, on utilise un selenium grid pour le browser précisé avec SELENIUM_BROWSER</li>
 *  <li>Sinon on instancie en local, un driver service avec les drivers récupérés par Maven et pour le browser précisé avec SELENIUM_BROWSER<li>
 * <ul>
 *
 */
public abstract class AbstractSeleniumTest {

	//private static final Logger logger = LoggerFactory.getLogger(AbstractSeleniumTest.class);

	/**
	 * Le browser sur lequel on fait les tests précisé par une variable
	 * d'environnement 'BROWSER'.
	 */
	public static String SELENIUM_BROWSER = getSystemPropFallbackEnv("SELENIUM_BROWSER");

	/**
	 * Si on utilise Selenium grid, on founit l'url par une variable d'envionnement
	 * 'SELENIUM_HUB_URL' sinon un driver service sera instancié localement à
	 * l'éxécution des tests.
	 */
	public static String SELENIUM_HUB_URL = getSystemPropFallbackEnv("SELENIUM_HUB_URL");

	/**
	 * L'url du front sur lequel va porter les tests selenium.
	 *
	 */
	public static String SELENIUM_FRONT_URL = getSystemPropFallbackEnv("SELENIUM_FRONT_URL");

	//seul présent par défaut sur l'usine logiciel (pour demo)
	public static Browser currentBrowser;

	/**
	 * Dans le cas d'un lancement local.
	 */
	public static DriverService localService;

	/**
	 * Le web driver local ou remote.
	 */
	public static WebDriver currentDriver;

	public static SoftAssertions softAssert;


	/**
	 * on recherche d'abord une propriété de JVM (-DXXX=...) sinon une variable d'environnement lié à l'OS
	 * @param name le nom de la propriété/variable recherchée.
	 * @return
	 */
	private static String getSystemPropFallbackEnv(String name) {
		String value = System.getProperty(name);
		if (isEmpty(value)) {
			value = System.getenv(name);
			if(!isEmpty(value)) {
				System.out.println("Found property :" + name + " from OS ENV VAR");
			}
		} else {
			System.out.println("Found property :" + name + " from JVM SYSTEM PROPERTIES");
		}
		if (isEmpty(value)) {
			System.out.println("Cannot found property :" + name + " in SYSTEM PROPERTIES or OS ENV VAR");
		}
		return value;
	}

	//Donne le driver courant instancité dans la classe du Hook à cause de sélénium.
	public static SoftAssertions getSoftAssert() {
		return softAssert;
	}

	@BeforeClass
	public static void setUpClass() throws Exception {
		if (softAssert == null){
			softAssert = new SoftAssertions();
		}
		//Si le browser n'est pas précisé, on ne peut rien faire.
		if (isEmpty(SELENIUM_BROWSER)) {
			if (currentBrowser == null) {
				currentBrowser = Browser.valueOf("CHROME");
				//throw new IllegalArgumentException(
				//		"Vous devez préciser un type de navigateur par une variable d'environnement 'SELENIUM_BROWSER' ou par le constructeur de la classe.");
			}
		} else {
			currentBrowser = Browser.valueOf(SELENIUM_BROWSER.toUpperCase());
		}
		//Si le hub n'est pas précisé, on démarre un service en local.
		if (isEmpty(SELENIUM_HUB_URL)) {
			localService = currentBrowser.getDriverService();
			if (localService == null) {
				throw new RuntimeException(
						"Impossible d'obtenir un driver service pour le navigateur " + currentBrowser.toString());
			}
			System.out.println("START LOCAL DRIVER SERVICE :"+currentBrowser.toString());
			localService.start();
		}
	}

	@AfterClass
	public static void createAndStopService() {
		//Si le hub n'est pas précisé, c'est que l'on avait démarrer un service en local.
		if (isEmpty(SELENIUM_HUB_URL)) {
			System.out.println("STOP LOCAL DRIVER SERVICE :"+currentBrowser.toString());
			//localService.stop();
		}
	}

	//Donne le driver courant instancité dans la classe du Hook à cause de sélénium.
	public static WebDriver getDriver() {
		return currentDriver;
	}





	public static boolean isElementPresent(By by) {
		if(currentDriver.findElements(by).size()<=0){
			return false;
		}else{
			return true;
		}
	}



	public static boolean isEmpty(String value) {
		return value == null || value.trim().length() == 0;
	}
}
