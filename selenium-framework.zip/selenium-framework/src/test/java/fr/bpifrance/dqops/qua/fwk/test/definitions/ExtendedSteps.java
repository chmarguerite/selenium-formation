package fr.bpifrance.dqops.qua.fwk.test.definitions;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.fr.Alors;
import cucumber.api.java.fr.Et;
import cucumber.api.java.fr.Quand;
import fr.bpifrance.dqops.qua.configuration.*;
import cucumber.api.java.After;
import cucumber.api.java.fr.Etantdonné;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest.currentDriver;
import static org.assertj.core.api.Assertions.assertThat;

public class ExtendedSteps extends ActionsBuilder {
    WebDriver driver;
    PageObjectManager pages;
    String refDemande;
    JavascriptExecutor js;
    public ExtendedSteps(TestContext testContext) {
        super(testContext);
        driver=this.getTestContext().getContextDriver();
        js = (JavascriptExecutor) driver;
        pages = this.getTestContext().getPageObjectManager();
    }

    @Quand("^j'ajoute un deuxième projet$")
    public void j_ajoute_un_deuxième_projet() throws Exception {

        js.executeScript("window.scrollBy(0,1000)");
        pages.get("ajouter un autre projet").click();
    }
    @Alors("^il n'est pas possible d'ajouter un deuxième projet$")
    public void il_n_est_pas_possible_d_ajouter_un_deuxième_projet() throws Exception {

        js.executeScript("window.scrollBy(0,1000)");
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        assertThat(pages.get("ajouter un autre projet")).isNull();
        driver.manage().timeouts().implicitlyWait(new ConfigFileReader().getImplicitlyWait(), TimeUnit.SECONDS);
    }

    @Alors("^il est possible d'ajouter un deuxième projet$")
    public void il_est_possible_d_ajouter_un_deuxième_projet() throws Exception {

        js.executeScript("window.scrollBy(0,1000)");
        assertThat(pages.get("ajouter un autre projet")).isNotNull();
    }
    @Quand("^je passe à l'étape suivante$")
    public void je_passe_à_l_étape_suivante() throws Exception {


        js.executeScript("window.scrollBy(0,1000)");
        pages.get("Suivant").click();
        pages.setPage(pages.get("Suivant").getDestinationPage());
        js.executeScript("window.scrollBy(0,-3000)");

    }

    @Quand("^j'ajoute le justificatif$")
    public void je_ajoute_le_justificatif() throws Throwable {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("justificatifs/etude.docx").getFile());
        pages.get("Ajouter_un_fichier").sendKeys(file.getAbsolutePath());
        new StandardSteps(getTestContext()).j_attends_la_fin_du_traitement();
        try{
            driver.findElement(By.xpath("//*[contains(text(),'etude.docx')]")).isDisplayed();
        }catch(Exception e){
            new StandardSteps(getTestContext()).j_attends_la_fin_du_traitement();
            Thread.sleep(90000);
            driver.navigate().refresh();

        }
    }

    @Et("^je récupère la référence de la demande$")
    public void je_récupère_la_référence_de_la_demande() {
        Pattern p = Pattern.compile("[0-9]{5}") ;
        Matcher m = p.matcher(driver.getCurrentUrl()) ;
        String result="";
        while (m.find()) {
            result=m.group() ;
        }
        refDemande = result;
    }

    @Et("^je recherche  de la demande référencée$")
    public void je_recherche_la_demande_référencée() throws Throwable {
        js.executeScript("window.scrollBy(0,-3000)");
        pages.setPage("Tableau de bord");
        pages.get("Recherche Référence").sendKeys(refDemande);
        new StandardSteps(getTestContext()).je_clique_sur_le_bouton("FILTRER");
        new StandardSteps(getTestContext()).j_attends_la_fin_du_traitement();
    }

    @Alors("^le pdf \"([^\"]*)\" contient les valeurs suivantes$")
    public void lePdfContientLesValeursSuivantes(String demande, List<String> textes) throws Throwable {
        Thread.sleep(10000);
        if(!driver.getClass().toString().contains("InternetExplorer") && !driver.getClass().toString().contains("Remote") ) {
            new StandardSteps(getTestContext()).j_attends_la_fin_du_traitement();
            this.je_récupère_la_référence_de_la_demande();
            PdfReader reader = new PdfReader(System.getProperty("user.home") + "\\downloads\\" + demande + "-" + refDemande + ".pdf");
            String pdfTexte="";
            for(int i = 1; i<=reader.getNumberOfPages(); i++) {
                pdfTexte = pdfTexte + "\n" + PdfTextExtractor.getTextFromPage(reader, i);
            }

            assertThat(pdfTexte).contains(textes);
            assertThat(pdfTexte).contains(refDemande);
        }else{
            // A traiter un jour
        }
    }

    @Et("^il est impossible de passer à l'étape suivante$")
    public void il_est_impossible_de_passer_l_etape_suivante() {
        js.executeScript("window.scrollBy(0,1000)");
        assertThat(pages.get("Suivant").getAttribute("disabled")).isNotEmpty();
    }

    @Et("^il est possible de passer à l'étape suivante$")
    public void il_est_possible_de_passer_l_etape_suivante() {
        js.executeScript("window.scrollBy(0,1000)");
        assertThat(pages.get("Suivant").getAttribute("disabled")).isNull();
    }

    @Et("^les champs suivants sont obligatoires$")
    public void les_champs_suivants_sont_obligatoires(List<String> textes) {
        textes.stream().forEach(texte ->{
            assertThat(pages.get(texte).getAttribute("required")).isNotEmpty();
        });
    }
    @Et("^les champs suivants sont facultatifs$")
    public void les_champs_suivants_sont_facultatifs(List<String> textes) {
        textes.stream().forEach(texte -> assertThat(pages.get(texte).getAttribute("required")).isNull());
    }

    @Alors("^il est affiché le message d'erreur \"([^\"]*)\"$")
    public void il_est_affiché_le_message_erreur(String message) throws Throwable {
        assertThat(pages.get("Message erreur").getText()).contains(message);
    }

    @Et("^j'ajoute un justificatif non conforme$")
    public void j_ajoute_le_justificatif_non_conforme() throws Throwable {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("justificatifs/non_conforme.js").getFile());
        pages.get("Ajouter_un_fichier").sendKeys(file.getAbsolutePath());
    }

    @Et("^j'ajoute un justificatif volumineux$")
    public void j_ajoute_le_justificatif_volumineux() throws Throwable {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("justificatifs/volumineux.xlsx").getFile());
        pages.get("Ajouter_un_fichier").sendKeys(file.getAbsolutePath());
        // new StandardSteps(getTestContext()).j_ajoute_le_fichier_suivant(file.getAbsolutePath());
    }

    @Quand("^je finalise la demande$")
    public void je_finalise_la_demande() throws Throwable {
        StandardSteps steps=new StandardSteps(getTestContext());
        steps.je_clique_sur_le_bouton("JE CONFIRME LCB-FT");
        steps.je_clique_sur_le_bouton("JE CONFIRME ACCEPTATION BANQUE");
        steps.je_clique_sur_le_bouton("FINALISER MA DEMANDE");
        steps.j_attends_la_fin_du_traitement();
    }
}
