package fr.bpifrance.dqops.qua.configuration;


import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.TestInstancePostProcessor;

public class LoggingExtension implements TestInstancePostProcessor {
    @Override
    public void postProcessTestInstance(Object testInstance,
                                        ExtensionContext context) throws Exception {
        System.out.println(testInstance.toString());
        System.out.println("LOGGER");
    }
}
