package fr.bpifrance.dqops.qua.configuration;
import fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest;
import org.openqa.selenium.WebDriver;

import static fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest.getDriver;

public class TestContext{ // extends DriverManager {
    private PageObjectManager pageObjectManager;

    public TestContext(){
        pageObjectManager = new PageObjectManager(getDriver());
    }
    public WebDriver getContextDriver(){
        return getDriver();
    }
    public PageObjectManager getPageObjectManager() {
        return pageObjectManager;
    }
}
