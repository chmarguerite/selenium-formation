package fr.bpifrance.dqops.qua.fwk.test.definitions;

import fr.bpifrance.dqops.qua.configuration.SeleniumElement;
import fr.bpifrance.dqops.qua.configuration.TestContext;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.internal.Coordinates;
import java.util.List;

public class ExtendedWebElement implements SeleniumElement {
    private WebElement standardWebElement;
    private String destinationPage;
    private String type;
    private String name;
    private TestContext testContext;
    private WebDriver driver;

    public ExtendedWebElement(WebDriver driver, WebElement s){
        this.driver=driver;
        this.standardWebElement = s;
    }

    public void saisir2(String charSequences) {
        System.out.println("je saisis2 avec l'extended");
        ((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'",  standardWebElement);
        standardWebElement.sendKeys(charSequences);

    }

    @Override
    public void click(){
        standardWebElement.click();
        System.out.println("je clique avec l'extended");
    }

    @Override
    public void submit() {

    }

    @Override
    public void sendKeys(CharSequence... charSequences) {

    }

    @Override
    public void clear() {

    }

    @Override
    public String getTagName() {
        return null;
    }

    @Override
    public String getAttribute(String s) {
        return null;
    }

    @Override
    public boolean isSelected() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }

    @Override
    public String getText() {
        return null;
    }

    @Override
    public List<WebElement> findElements(By by) {
        return null;
    }

    @Override
    public WebElement findElement(By by) {
        return null;
    }

    @Override
    public boolean isDisplayed() {
        return false;
    }

    @Override
    public Point getLocation() {
        return null;
    }

    @Override
    public Dimension getSize() {
        return null;
    }

    @Override
    public Rectangle getRect() {
        return null;
    }

    @Override
    public String getCssValue(String s) {
        return null;
    }

    @Override
    public <X> X getScreenshotAs(OutputType<X> outputType) throws WebDriverException {
        return null;
    }

    @Override
    public void setDestinationPage(String destination) {

    }

    @Override
    public void setType(String type) {

    }

    @Override
    public void setName(String element) {

    }

    public String getDestinationPage() {
        return destinationPage;
    }

    @Override
    public void select(String valeur) {

    }

    public String getType() {
        return type;
    }

    @Override
    public SeleniumElement setTestContext(TestContext testContext) {
        return null;
    }


    @Override
    public Object getValue() {
        return null;
    }

    @Override
    public String getAfterEvent() {
        return null;
    }

    @Override
    public void setAfterEvent(String afterEvent) {

    }

    @Override
    public WebElement getElement() {
        return standardWebElement;
    }

    @Override
    public String getMethod() {
        return null;
    }

    @Override
    public void setMethod(String method) {

    }


    public String getName() {
        return name;
    }

    @Override
    public Coordinates getCoordinates() {
        return null;
    }

    public void setDriver(WebDriver driver) {
        this.driver=driver;
    }
}
