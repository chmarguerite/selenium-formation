package fr.bpifrance.dqops.qua.configuration;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import gherkin.ast.Step;
import org.apache.commons.io.FileUtils;
import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.remote.DesiredCapabilities;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import static fr.bpifrance.dqops.qua.configuration.AbstractSeleniumTest.*;

/**
 * Afin d'avoir de supprimer/recréér le web driver entre chaque scénario.
 * https://www.toolsqa.com/cucumber/cucumber-hooks/
 *
 */
public class Hooks {

	//private static final Logger logger = LoggerFactory.getLogger(Hooks.class);


	@Before
	public void setUp() throws MalformedURLException {

		if (isEmpty(SELENIUM_HUB_URL)) {
			//local Service est instancié dans AbstractSeleniumTest
			currentDriver = currentBrowser.getWebDriverFor(localService);
		//	logger.info("CREATE LOCAL WEB DRIVER for "+currentBrowser.toString()+" "+currentDriver.toString());
			if (currentDriver == null) {
				throw new RuntimeException(
						"Impossible d'obtenir un web driver pour le navigateur " + currentBrowser.toString());
			}
		} else {
			//On utilise le Bpi remote Web driver avec le hub selenium
			Capabilities cap= currentBrowser.getCapabilitiesBrowser();
			currentDriver = new Browser.BpiRemoteWebDriver(new URL(SELENIUM_HUB_URL),
					currentBrowser.getCapabilitiesBrowser());

		//	logger.info("CREATE REMOTE WEB DRIVER "+currentDriver.toString()+" WITH CAPABILITIES "+cap.toString());
		}
		currentDriver.manage().timeouts().implicitlyWait(new ConfigFileReader().getImplicitlyWait(), TimeUnit.SECONDS);
	}

	@AfterStep(order = 1)
	public void finStep(Scenario scenario) throws IOException {
		//if (scenario.isFailed()) {
			final byte[] screenshot = ((TakesScreenshot) currentDriver).getScreenshotAs(OutputType.BYTES);
			scenario.embed(screenshot, "image/png");
			File scrFile = ((TakesScreenshot)currentDriver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("target/failsafe-reports/screenshot.png"));
		//}
	}
	/*@After(order = 2)
	public void finScenario(Scenario scenario) {

		final byte[] screenshot = ((TakesScreenshot) currentDriver).getScreenshotAs(OutputType.BYTES);
		scenario.embed(screenshot, "image/png");
	}*/


	@After(order = 1)
	public void setDown() {
		/*currentDriver.quit();
		currentDriver=null;*/
		softAssert.assertAll();
	}
}
