package fr.bpifrance.dqops.qua.configuration;


import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebTableElement {
    private WebElement table;
    private int currentRow;
    public WebTableElement(WebElement table) {
        this.table = table;
    }


    WebElement getCellByText(String texte){
        try{
            for (int i=0;i <this.getRows().size();i++){

                if(texte.startsWith("#") && texte.endsWith("#")) {
                    String regexp="(" + texte.substring(1,texte.length()-1) +")";
                    Pattern p = Pattern.compile(regexp);
                    Matcher m = p.matcher(table.findElements(By.tagName("tr")).get(i).getText());
                    if (m.find()) {
                        this.setCurrentRow(i);
                        return table.findElement(By.xpath("//td[text()='" + m.group().toString() +"']"));
                    }
                }else{
                    this.setCurrentRow(i);
                    if(this.getRows().get(i).getText().contains(texte)) {
                        return table.findElement(By.xpath("//td[text()='" + texte + "']"));
                    }
                }
            }
        }catch(NoSuchElementException e){
            return null;
        }
        return null;
    }

    public List<WebElement> getRows() {
        if (table.findElements(By.xpath("(tbody|thead)/child::tr")).size() >0){
            return table.findElements(By.xpath("(tbody|thead)/child::tr"));
        }else{
            return table.findElements(By.xpath("child::tr"));
        }
    }
    public List<WebElement> getCellsRow(int ligne) {
        return this.getRows().get(ligne).findElements(By.xpath("child::td|child::th"));
    }

    public WebElement getCell(int ligne, int colonne){
        return this.getCellsRow(ligne).get(colonne);
    }


    public WebElement getCell(int ligne, String colonne){
        int num_colonne=0;
        for(WebElement e:this.getCellsRow(0)){
            if(e.getText().equals(colonne)){
                System.out.println("colonne trouvee: " + num_colonne);
                return this.getCell(ligne, num_colonne);
            }else{
                num_colonne++;
            }
        }
        return null;
    }

    public Integer getCurrentRow() {
        return currentRow;
    }

    public void setCurrentRow(Integer currentRow) {
        this.currentRow = currentRow;
    }

    public WebElement getCellByTextInCurrentRow(String texte) {
        try{
            if(texte.startsWith("#") && texte.endsWith("#")) {
                String regexp="(" + texte.substring(1,texte.length()-1) +")";
                Pattern p = Pattern.compile(regexp);
                Matcher m = p.matcher(this.getRows().get(this.getCurrentRow()).getText());
                if (m.find()) {
                    return this.getRows().get(this.getCurrentRow()).findElement(By.xpath("./td[text()='" + m.group().toString() + "']"));
                }else{return null;}
            }else{
                return this.getRows().get(this.getCurrentRow()).findElement(By.xpath("./td[text()='" + texte + "']"));
            }
        }catch(NoSuchElementException e){
            return null;
        }
    }

    public List<List<String>> getRawList(){
        List<List<String>> liste = new ArrayList<List<String>>();
        List<String> ligne;
        for(int i=0;i<=this.getRows().size()-1;i++){
            ligne = new ArrayList<String>();
            for(WebElement e: this.getCellsRow(i)){
                ligne.add(e.getText());
            }
            liste.add(ligne);
        }
        return liste;
    }
}
